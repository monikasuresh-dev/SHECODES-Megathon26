"""
Module: static_responses.py
Purpose: Person B - Deterministic, patient-grounded offline response generator.

Provides reassuring, dementia-appropriate responses grounded in patient.json memory anchors
when the external LLM API is offline, disabled, or rate-limited.

DEMENTIA CARE PRINCIPLES:
- Validation Therapy: never argue, dispute, or abruptly correct dates/memories.
- Grounding Anchors: mention familiar anchors (Sarah's 5 PM visit, Barnaby the golden retriever, cozy armchair).
- Short & Gentle: 1 to 2 calming sentences.
"""

from typing import Any, Dict, Optional


class StaticResponseGenerator:
    """
    Generates comforting, context-aware responses without requiring external LLM network calls.
    """

    def __init__(self, patient_profile: Optional[Dict[str, Any]] = None) -> None:
        self.patient_profile = patient_profile or {}

    def update_profile(self, patient_profile: Dict[str, Any]) -> None:
        self.patient_profile = patient_profile

    def generate_response(
        self,
        sanitized_message: str,
        intelligence_result: Dict[str, Any],
    ) -> str:
        """
        Generate a patient-specific comforting response based on message content,
        patient memory anchors, and intelligence signals.
        """
        lower = sanitized_message.lower()
        signals = intelligence_result.get("signals", [])
        risk_level = intelligence_result.get("risk_level", "GREEN")
        repeated_topic = intelligence_result.get("repeated_topic", "")

        # Extract patient anchors
        preferred_name = self.patient_profile.get("preferred_name", "Eleanor")
        daughter_info = (
            self.patient_profile.get("family_and_contacts", {})
            .get("primary_caregiver", {})
        )
        daughter_name = daughter_info.get("name", "Sarah").split()[0]
        visit_schedule = daughter_info.get("visit_schedule", "this evening around 5:00 PM")
        
        comfort_anchors = self.patient_profile.get("comfort_anchors", {})
        pet_name = comfort_anchors.get("cherished_pet", {}).get("name", "Barnaby")
        room_number = self.patient_profile.get("room_number", "Oakwood Suite 14")

        # ----------------------------------------------------------------------
        # 1. ACUTE HELP / DISTRESS SIGNALS (RED / HIGH DISTRESS)
        # ----------------------------------------------------------------------
        if "help_request" in signals or "help" in lower:
            return (
                f"I am right here with you, {preferred_name}. "
                f"You are completely safe, and I have notified {daughter_name} and our staff to check in on you."
            )

        if "fear" in signals or any(w in lower for w in ["scared", "terrified", "frightened"]):
            return (
                f"It is completely okay to feel a little worried, {preferred_name}. "
                f"You are safe here in {room_number}. Let's take a slow, gentle breath together."
            )

        # ----------------------------------------------------------------------
        # 2. CONFUSION & DISORIENTATION SIGNALS
        # ----------------------------------------------------------------------
        if "confusion" in signals or "lost" in signals or any(w in lower for w in ["where am i", "lost", "home"]):
            return (
                f"You are right in your cozy room at {room_number}, sitting in your favorite armchair. "
                f"Everything is peaceful, and {daughter_name} will be visiting you {visit_schedule}."
            )

        # ----------------------------------------------------------------------
        # 3. REPEATED DAUGHTER / FAMILY INQUIRIES
        # ----------------------------------------------------------------------
        if repeated_topic == "daughter" or any(w in lower for w in ["daughter", "sarah"]):
            return (
                f"{daughter_name} loves you dearly, {preferred_name}. "
                f"She will be here to see you {visit_schedule}. {pet_name} is doing wonderfully too."
            )

        if "son" in lower or "david" in lower:
            return (
                f"David called from Seattle to send you all his love, {preferred_name}. "
                f"He is looking forward to chatting on Sunday morning."
            )

        # ----------------------------------------------------------------------
        # 4. ROUTINE & COMFORT ANCHORS (TEA, GARDEN, WEATHER, MUSIC)
        # ----------------------------------------------------------------------
        if any(w in lower for w in ["tea", "breakfast", "lunch", "dinner", "eat", "hungry"]):
            return (
                f"Nurse Maria will bring your warm chamomile tea and biscuits shortly, {preferred_name}. "
                f"It's nice and warm today."
            )

        if any(w in lower for w in ["weather", "sun", "rain", "outside", "garden"]):
            return (
                f"It is a lovely day outside, {preferred_name}. "
                f"The yellow roses in the courtyard garden are blooming beautifully."
            )

        if any(w in lower for w in ["barnaby", "dog", "pet"]):
            return (
                f"{pet_name} is having a happy day playing in the garden at {daughter_name}'s house. "
                f"He wags his tail whenever we mention your name."
            )

        if any(w in lower for w in ["music", "piano", "song", "chopin"]):
            return (
                f"Listening to Chopin's piano nocturnes always brings so much calm. "
                f"Would you like to relax and listen for a while?"
            )

        # ----------------------------------------------------------------------
        # 5. GREETINGS & GENERAL CONVERSATION
        # ----------------------------------------------------------------------
        if any(w in lower for w in ["hello", "hi", "good morning", "good afternoon", "good evening"]):
            return (
                f"Good morning, {preferred_name}! It is wonderful to hear your voice. "
                f"How are you feeling today?"
            )

        if any(w in lower for w in ["thank you", "thanks"]):
            return (
                f"You are always so kind, {preferred_name}. I am always here whenever you want to talk."
            )

        # General comforting default
        return (
            f"I hear you, {preferred_name}. You are warm, comfortable, and safe here in {room_number}. "
            f"I am right by your side."
        )
